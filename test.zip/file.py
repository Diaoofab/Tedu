multiplychart.py
